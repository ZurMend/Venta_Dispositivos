from flask import Flask, render_template, jsonify, request
import random
from zuisfre import predecir_estado

app = Flask(__name__)
actuadores = {
    "bomba_riego": False,
    "ventilador": False,
    "luces_crecimiento": False,
    "cubierta_invernadero": True 
}

configuracion = {
    "umbral_riego": 30,
    "max_temp": 35,
    "max_viento": 40,
    "min_nutrientes": 20
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/datos')
def api_datos():
    datos_sensores = {
        "humedad_suelo": random.randint(10, 90),
        "temp_suelo": random.randint(15, 30),
        "n": random.randint(10, 100),
        "p": random.randint(10, 100),
        "k": random.randint(10, 100),
        "temp_aire": random.randint(10, 45),
        "humedad_aire": random.randint(20, 95),
        "luminosidad": random.randint(10000, 90000),
        "viento": random.randint(0, 60),
        "lluvia": random.choice([0, 0, 0, 10, 0]) 
    }

    diagnostico = predecir_estado(
        datos_sensores["humedad_suelo"],
        datos_sensores["temp_suelo"],
        datos_sensores["n"], datos_sensores["p"], datos_sensores["k"],
        datos_sensores["temp_aire"],
        datos_sensores["humedad_aire"],
        datos_sensores["luminosidad"],
        datos_sensores["viento"],
        datos_sensores["lluvia"],
        configuracion 
    )
    return jsonify({
        "sensores": datos_sensores,
        "ia": diagnostico,
        "actuadores": actuadores,   
        "config": configuracion      
    })

@app.route('/api/control', methods=['POST'])
def api_control():
    data = request.json
    dispositivo = data.get('dispositivo')
    accion = data.get('accion') 
    
    if dispositivo in actuadores:
        actuadores[dispositivo] = accion
        print(f" CONTROL MANUAL: {dispositivo} -> {accion}")
        return jsonify({"status": "ok", "nuevo_estado": actuadores})
    
    return jsonify({"status": "error", "mensaje": "Dispositivo no encontrado"}), 400

@app.route('/api/configurar', methods=['POST'])
def api_configurar():
    global configuracion
    data = request.json
    
    for key, value in data.items():
        if key in configuracion:
            configuracion[key] = float(value)
            
    print(f"CONFIGURACIÓN ACTUALIZADA: {configuracion}")
    return jsonify({"status": "ok", "config": configuracion})

if __name__ == '__main__':
    app.run(debug=True, port=5000)