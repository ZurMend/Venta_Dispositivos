let primeraCarga = true;

async function actualizarDatos() {
    try {
        const respuesta = await fetch('/api/datos');
        const data = await respuesta.json();

        document.getElementById('soil-moisture').innerText = data.sensores.humedad_suelo;
        document.getElementById('air-temp').innerText = data.sensores.temp_aire;
        document.getElementById('wind-speed').innerText = data.sensores.viento;
        document.getElementById('nutrient-n').innerText = data.sensores.n;

        const mlBadge = document.getElementById('ml-result');
        mlBadge.innerText = data.ia.estado_general;
        
        if (data.ia.codigo_alerta === 0) mlBadge.style.backgroundColor = "#e74c3c"; // Rojo
        else if (data.ia.codigo_alerta === 2) mlBadge.style.backgroundColor = "#f39c12"; // Naranja
        else mlBadge.style.backgroundColor = "rgba(255,255,255,0.2)";

        const detailsList = document.getElementById('ml-details');
        detailsList.innerHTML = ""; 
        data.ia.detalles.forEach(msg => {
            const li = document.createElement('li');
            li.innerText = msg;
            detailsList.appendChild(li);
        });

        actualizarEstadoBotones(data.actuadores);
        if (primeraCarga) {
            document.getElementById('conf-riego').value = data.config.umbral_riego;
            document.getElementById('conf-temp').value = data.config.max_temp;
            document.getElementById('conf-viento').value = data.config.max_viento;
            primeraCarga = false;
        }

    } catch (error) {
        console.error("Error fetching data:", error);
    }
}
function actualizarEstadoBotones(estados) {
    if(document.getElementById('btn-bomba')) 
        document.getElementById('btn-bomba').checked = estados.bomba_riego;
    
    if(document.getElementById('btn-vent')) 
        document.getElementById('btn-vent').checked = estados.ventilador;
    
    if(document.getElementById('btn-luz')) 
        document.getElementById('btn-luz').checked = estados.luces_crecimiento;
}

async function toggleActuator(idDispositivo, estado) {
    console.log(`Enviando comando: ${idDispositivo} -> ${estado}`);
    
    try {
        const response = await fetch('/api/control', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                dispositivo: idDispositivo, 
                accion: estado 
            })
        });
        const result = await response.json();
        console.log("Respuesta servidor:", result);
    } catch (error) {
        console.error("Error enviando comando:", error);
        document.getElementById(idDispositivo === 'bomba_riego' ? 'btn-bomba' : 'btn-vent').checked = !estado;
    }
}

async function guardarConfig() {
    const nuevaConfig = {
        umbral_riego: document.getElementById('conf-riego').value,
        max_temp: document.getElementById('conf-temp').value,
        max_viento: document.getElementById('conf-viento').value
    };

    try {
        const response = await fetch('/api/configurar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nuevaConfig)
        });
        
        if(response.ok) {
            alert("Configuración guardada y aplicada en zuisfre.py");
            actualizarDatos();
        }
    } catch (error) {
        alert("Error al guardar configuración");
    }
}

setInterval(actualizarDatos, 2000);
window.onload = actualizarDatos;