import numpy as np

def predecir_estado(humedad_suelo, temp_suelo, n, p, k, temp_aire, humedad_aire, luminosidad, viento, lluvia):
    #Ningún menso le mueve sin previa consideración de todos
    mensajes = []
    acciones = []
    codigo_alerta = 1 
    if humedad_suelo < 30:
        if lluvia > 5:
            mensajes.append("Suelo seco, pero hay lluvia detectada (Esperar)")
        else:
            mensajes.append("Estrés Hídrico Crítico")
            acciones.append("ACTIVAR_VALVULA_RIEGO")
            codigo_alerta = 0

    if humedad_aire > 85 and (20 < temp_aire < 30) and viento < 5:
        mensajes.append(" Alto Riesgo de Hongos (Humedad estancada)")
        acciones.append("ACTIVAR_VENTILACION")
        codigo_alerta = 2

    if n < 20 or p < 15 or k < 20:
        deficiencias = []
        if n < 20: deficiencias.append("Nitrógeno")
        if p < 15: deficiencias.append("Fósforo")
        if k < 20: deficiencias.append("Potasio")
        
        mensajes.append(f"Deficiencia de Nutrientes: {', '.join(deficiencias)}")
        acciones.append("ACTIVAR_DOSIFICADOR_FERTILIZANTE")
        if codigo_alerta != 0: codigo_alerta = 2

    if temp_aire > 35 or luminosidad > 80000:
        mensajes.append("Radiación/Calor Extremo")
        acciones.append("DESPLEGAR_MALLA_SOMBRA") 
        
    if viento > 40:
        mensajes.append("Viento Fuerte Detectado")
        acciones.append("CERRAR_INVERNADERO") 

    estado_final = "ÓPTIMO: Cultivo en buen estado"
    if codigo_alerta == 0:
        estado_final = " ALERTA CRÍTICA: Acción Requerida Inmediata"
    elif codigo_alerta == 2:
        estado_final = "PRECAUCIÓN: Monitorear condiciones"

    if not mensajes:
        mensajes.append("Parámetros dentro de rango normal.")

    return {
        "estado_general": estado_final,
        "codigo_alerta": codigo_alerta, 
        "detalles": mensajes,
        "acciones_recomendadas": acciones,
        "confianza_modelo": "96.2%"
    }